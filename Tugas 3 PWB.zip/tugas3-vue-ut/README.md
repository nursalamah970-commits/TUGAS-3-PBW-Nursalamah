# Tugas Praktik 3 - SITTA (Vue.js 2)
Cara jalan: buka folder ini dengan web server lokal (karena memakai fetch), mis.
- VS Code -> Live Server, atau
- `python -m http.server 8000` lalu buka http://localhost:8000

Komponen: ba-stock-table, do-tracking, order-form, status-badge, app-modal (js/components + templates/).
Template dimuat dari /templates oleh Api.loadTemplates() dengan id tpl-stock, tpl-tracking, tpl-order, tpl-badge, tpl-modal.
